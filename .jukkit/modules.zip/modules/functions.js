const hello = require('./functions/hello');

module.exports = {
    hello
};

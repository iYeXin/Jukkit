const libs = require('./libs');
const functions = require('./functions');

jukkit.log('插件正在加载');

jukkit.onEnable(() => {
    functions.hello.init();
});

jukkit.onDisable(() => {
    jukkit.log('插件已卸载');
});
